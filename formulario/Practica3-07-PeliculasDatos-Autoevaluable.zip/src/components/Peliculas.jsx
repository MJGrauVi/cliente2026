import Pelicula from "./Pelicula.jsx";
import Contenedor from "./Contenedor.jsx";
import archivoPelis from "../assets/archivoPelis2.json";

const Peliculas = () => {
  return (
    <Contenedor>
      {archivoPelis.peliculas.length !== 0 ? (
        archivoPelis.peliculas.map((peli, index) => (
          <Pelicula key={index} datos={peli}>
            {peli.resumen}
          </Pelicula>
        ))
      ) : (
        <h2>¡No hay películas, el archivo está vacío!</h2>
      )}
    </Contenedor>
  );
};

export default Peliculas;
