import "./App.css";
import React from "react";
import Peliculas from "./components/Peliculas.jsx";

const App = () => {
  return (
    <div>
      <h1>Mis Películas</h1>
      <Peliculas />
    </div>
  );
};

export default App;
