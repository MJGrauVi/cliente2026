import React from 'react'
import generar

const estadoListado = () => {
  return (
    <div>estadoListado</div>
  )
}

export default estadoListado