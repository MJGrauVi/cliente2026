import "./App.css";

import Peliculas from "./components/Peliculas.jsx";

const App = () => {
  return (
    <div>
      <h1>Películas en cartelera.</h1>
      <Peliculas />
    </div>
  );
};

export default App;
