import "./Footer.css";
const Footer = ()=>{
    return(
        <div className="contenedor-footer">
            <p>Pie de página</p>
        </div>
    )
}
export default Footer;