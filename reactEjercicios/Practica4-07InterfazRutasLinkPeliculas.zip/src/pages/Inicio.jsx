import "./Inicio.css";
const Inicio = ()=>{
    return(
        <div className="contenedor-inicio">
            <h2>Bienvenido, página Inicio.</h2>
           

        </div>
    )
}
export default Inicio;