import React from 'react'
import { Link, Outlet } from "react-router-dom";

const GaleriaDirector = () => {
  return (
    <div>Cartelera por director</div>
  )
}

export default GaleriaDirector;