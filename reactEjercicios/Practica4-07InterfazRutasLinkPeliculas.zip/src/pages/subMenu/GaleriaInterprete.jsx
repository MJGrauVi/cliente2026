import React from 'react'

const GaleriaInterprete = () => {
  return (
    <div>Cartelera por Interprete.</div>
  )
}

export default GaleriaInterprete;