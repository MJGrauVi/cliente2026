import React from 'react'

const GaleriaTitulo = () => {
  return (
    <div>Cartelera por Título</div>
  )
}

export default GaleriaTitulo;