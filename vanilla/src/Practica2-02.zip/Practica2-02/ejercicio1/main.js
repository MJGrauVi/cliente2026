"use strict";
import { obtenerMes } from "../../../bibliotecaf/funcionesEjercicios.js";
//Practica 2-02, ejercicio 1.
obtenerMes(hola);
