"use strict";
import {analisisNumerico} from "../../../bibliotecaf/funcionesEjercicios.js";

//Ejercicio 2 analisisNumerico.

let resultado = analisisNumerico("hola");
console.log(resultado);
