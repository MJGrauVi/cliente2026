"use strict";
import {
  multiploTres
} from "../../../bibliotecaf/funcionesEjercicios.js";


console.log(multiploTres("hola")); 
