"use strict";
import { calcularPotencia } from "../../../bibliotecaf/funcionesEjercicios.js";

console.log(calcularPotencia(9,3));

