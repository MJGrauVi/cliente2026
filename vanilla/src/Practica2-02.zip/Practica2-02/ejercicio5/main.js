"use strict"
import {calcularMedia} from "../../../bibliotecaf/funcionesEjercicios.js";

console.log(calcularMedia(5, -8, 16, 9, 4));
console.log(calcularMedia(5, 8, 16, 9, 4));
console.log(calcularMedia(5, 8, -16, 0, 4));