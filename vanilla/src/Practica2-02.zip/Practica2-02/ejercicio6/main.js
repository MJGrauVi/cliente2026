"use strict"
//Para este ejercicio he reutilizado las funciones del profesor.
import { calculadora} from "../../../bibliotecaf/funcionesEjercicios.js";

calculadora(10, 5, "-");
calculadora(10, 5, "*");
calculadora(10, 5, "/");
calculadora(10, 5, "%");
calculadora(10, 0, "/");